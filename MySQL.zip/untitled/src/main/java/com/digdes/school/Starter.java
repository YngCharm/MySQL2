package com.digdes.school;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class Starter {
    public List<Map<String, Object>> list = new ArrayList<>();

    public Starter() {

    }

    public List<Map<String, Object>> execute(String request) {

        switch (readRequest(request)) {

            case "INSERT" -> insertListElement(request);
            case "UPDATE" -> updateListElement(request);
            case "DELETE" -> deleteListElement(request);
            case "SELECT" -> selectListElement(request);
            default -> throw new RuntimeException("Incorrect request.");
        }
        return list;
    }

    private String readRequest(String request) {
        if (request.startsWith("INSERT") || request.startsWith("UPDATE") ||
                request.startsWith("DELETE") || request.startsWith("SELECT")) ;
        return request.substring(0, 6);
    }

    private void selectListElement(String request) {
    }

    private void deleteListElement(String request) {
    }

    private void updateListElement(String request) {
    }

    private void insertListElement(String request) {

        request = request.replaceAll(" ", "");
        request = request.replaceAll("INSERTVALUES", "");


        System.out.println(request);

        int symbolIndex = request.indexOf("=");

        if (symbolIndex != -1) {
            String beforeSymbol = request.substring(0, symbolIndex);
            String removeComma = beforeSymbol.replaceAll("[^A-Za-zА-Яа-я0-9]", "");
            System.out.println(removeComma);


        }
    }
}
